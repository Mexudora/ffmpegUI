import QtQuick
import QtQuick.Controls
import QtQuick.Dialogs
import QtQuick.Layouts
import FFmpegUI

ColumnLayout {
    id: form
    property alias inputFile: conversion.inputFile
    property real durationSeconds: 0
    readonly property bool busy: runner.busy
    spacing: 12

    function cancel() {
        runner.cancel()
    }

    ConversionCommand {
        id: conversion
    }

    ConversionRunner {
        id: runner
    }

    FileDialog {
        id: outputDialog
        title: qsTr("Choose an output file")
        fileMode: FileDialog.SaveFile
        // Existing destinations are rejected by ConversionCommand.
        options: FileDialog.DontConfirmOverwrite
        defaultSuffix: conversion.container
        nameFilters: conversion.container === "mp4"
                     ? [qsTr("MP4 files (*.mp4)")]
                     : [qsTr("MKV files (*.mkv)")]
        onAccepted: {
            if (!runner.busy)
                conversion.outputFile = selectedFile
        }
    }

    MenuSeparator {
        Layout.fillWidth: true
    }

    Label {
        text: qsTr("Conversion settings")
        font.pixelSize: 24
    }

    Label {
        Layout.fillWidth: true
        text: qsTr("The output will contain the first video stream (excluding cover art) and the first audio stream, when present.")
        wrapMode: Text.WordWrap
    }

    GridLayout {
        Layout.fillWidth: true
        enabled: !runner.busy
        columns: 2
        columnSpacing: 16
        rowSpacing: 12

        Label { text: qsTr("Container") }
        ComboBox {
            Layout.fillWidth: true
            model: ["MP4", "MKV"]
            onActivated: conversion.container = currentIndex === 0 ? "mp4" : "mkv"
        }

        Label { text: qsTr("Video") }
        ComboBox {
            Layout.fillWidth: true
            model: [qsTr("H.264 (libx264)"), qsTr("Copy without re-encoding")]
            onActivated: conversion.videoCodec = currentIndex === 0 ? "libx264" : "copy"
        }

        Label { text: qsTr("Audio") }
        ComboBox {
            Layout.fillWidth: true
            model: ["AAC", qsTr("Copy without re-encoding")]
            onActivated: conversion.audioCodec = currentIndex === 0 ? "aac" : "copy"
        }
    }

    Label {
        Layout.fillWidth: true
        visible: conversion.videoCodec === "copy" || conversion.audioCodec === "copy"
        text: qsTr("Copying requires the source codec to be supported by the selected container.")
        wrapMode: Text.WordWrap
    }

    Label {
        text: qsTr("Output file")
    }

    RowLayout {
        Layout.fillWidth: true
        enabled: !runner.busy

        TextField {
            Layout.fillWidth: true
            readOnly: true
            selectByMouse: true
            text: conversion.outputPath
            placeholderText: qsTr("Choose a new file with the selected container extension")
        }

        Button {
            text: qsTr("Choose…")
            onClicked: outputDialog.open()
        }
    }

    Label {
        Layout.fillWidth: true
        visible: !runner.busy && conversion.error.length > 0
        text: conversion.error
        textFormat: Text.PlainText
        wrapMode: Text.WordWrap
    }

    Label {
        text: qsTr("Command for PowerShell")
        font.bold: true
    }

    TextArea {
        Layout.fillWidth: true
        Layout.preferredHeight: 140
        readOnly: true
        selectByMouse: true
        wrapMode: TextEdit.WrapAnywhere
        textFormat: TextEdit.PlainText
        text: conversion.commandPreview
        placeholderText: qsTr("The command will appear after the settings are valid")
    }

    Button {
        text: qsTr("Copy command")
        enabled: conversion.valid && !runner.busy
        onClicked: conversion.copyPreview()
    }

    RowLayout {
        Button {
            text: qsTr("Start conversion")
            enabled: conversion.valid && !runner.busy
            onClicked: runner.start(conversion, form.durationSeconds)
        }

        Button {
            text: qsTr("Cancel")
            enabled: runner.busy && !runner.cancelling
            onClicked: runner.cancel()
        }
    }

    Label {
        Layout.fillWidth: true
        text: runner.statusText
        wrapMode: Text.WordWrap
    }

    ProgressBar {
        Layout.fillWidth: true
        visible: runner.state !== ConversionRunner.Idle
        from: 0
        to: 1
        value: Math.max(0, runner.progress)
        indeterminate: runner.busy && runner.progress < 0
    }

    Label {
        visible: runner.state !== ConversionRunner.Idle
        text: runner.progress >= 0
              ? qsTr("%1%").arg(Math.floor(runner.progress * 100))
              : qsTr("Progress percentage is unavailable.")
    }

    Label {
        Layout.fillWidth: true
        visible: !runner.busy && runner.outputPath.length > 0
        text: qsTr("Result file: %1").arg(runner.outputPath)
        textFormat: Text.PlainText
        wrapMode: Text.WrapAnywhere
    }

    Label {
        Layout.fillWidth: true
        visible: runner.error.length > 0
        text: runner.error
        textFormat: Text.PlainText
        color: "#b3261e"
        wrapMode: Text.WrapAnywhere
    }

    Label {
        text: qsTr("FFmpeg log (latest messages)")
        font.bold: true
    }

    ScrollView {
        Layout.fillWidth: true
        Layout.preferredHeight: 180

        TextArea {
            readOnly: true
            selectByMouse: true
            textFormat: TextEdit.PlainText
            wrapMode: TextEdit.WrapAnywhere
            text: runner.log
        }
    }
}
